#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cmath>
#include <algorithm>
#include <string>
#include <vector>
#include <set>
#include <bitset>
#define log2(x) log((x)) / log(2)
using namespace std;

vector<string> addresses;
int s, n, m;

//cache block class, similar as linked list
class Block
{
public:
	Block(int tag)
	{
		this->tag = tag;
		nextBlock = NULL;
		orderinSet = 1;
	}
	int getTag() { return this->tag; }
	void setOrder(int order) { this->orderinSet = order; }
	int getorder() { return this->orderinSet; };
	void setNextBlock(Block *next) { this->nextBlock = next; };
	Block *getNextBlock() { return this->nextBlock; };

private:
	int tag;
	int orderinSet;
	Block *nextBlock;
};

//printing guideline when wrong argument input
void help()
{
	cout << "Wrong argument" << endl;
	cout << "cache_simulator -s <S> -n <N> -m <M> <input_file_name>" << endl;
	cout << "	-s <S> : the number of sets in a cache (power of 2)" << endl;
	cout << "	-n <N> : the number of blocks in a set (power of 2)" << endl;
	cout << "	-m <M> : the number of words in a block (power of 2)" << endl;
}

//reading input file
bool readFile(string file_name)
{
	ifstream input_file(file_name.data());
	if (input_file.is_open())
	{
		string address;
		while (getline(input_file, address))
		{
			addresses.push_back(address);
		}
		input_file.close();
		return true;
	}
	else
		return false;
}

//function finding cache block
//automatically increments block order number when indexing
//when matching tag found, automatically set as front block of set(LRU)
bool findBlock(Block *&set, int tag, int n)
{
	Block *temp = set;
	while (true)
	{
		if (temp->getTag() == tag)
		{
			if (temp->getorder() != 1)
			{
				Block *t = set;
				while (t->getNextBlock() != temp)
				{
					t = t->getNextBlock();
				}
				t->setNextBlock(temp->getNextBlock());
				temp->setNextBlock(set);
				temp->setOrder(1);
				set = temp;
			}
			return true;
		}
		else
		{
			if (temp->getorder() == n)
			{
				Block *t = set;
				while (t->getNextBlock() != temp)
				{
					t = t->getNextBlock();
				}
				t->setNextBlock(NULL);
				delete temp;
				return false;
			}
			else
			{
				temp->setOrder(temp->getorder() + 1);
				temp = temp->getNextBlock();
				if (!temp)
				{
					return false;
				}
			}
		}
	}
}

int main(int argc, char *argv[])
{
	if (argc != 8)
	{
		help();
		return 1;
	}

	//parsing argument from command line input
	string input_file_name;
	for (int i = 1; i < argc; i += 2)
	{
		if (i == 7)
		{
			input_file_name = string(argv[i]);
			break;
		}
		string opt(argv[i]);
		if (opt == "-s")
		{
			s = atoi(argv[i + 1]);
		}
		else if (opt == "-n")
		{
			n = atoi(argv[i + 1]);
		}
		else if (opt == "-m")
		{
			m = atoi(argv[i + 1]);
		}
		else
		{
			help();
			return 2;
		}
	}

	//checking valid argument number
	if ((s % 2 != 0 && s != 1) || (n % 2 != 0 && n != 1) || (m % 2 != 0 && m != 1))
	{
		help();
		return 3;
	}

	//checking valid input file
	if (!readFile(input_file_name))
	{
		cout << "Input File Error" << endl;
		return 4;
	}

	//making cache using vector, output file
	vector<Block *> cache(s + 1);
	ofstream output((input_file_name.substr(0, input_file_name.size() - 3) + ".out").data());
	int hit = 0;

	//cache memory accessing
	for (int i = 0; i < addresses.size(); i++)
	{
		unsigned int ca = strtoul(addresses[i].c_str(), NULL, 0);
		//bitset<32> x(ca);
		//parsing set index, tag from memory address
		int setIndex = (ca >> (int)(2 + log2(m))) % s;
		int tag = ca >> (int)(2 + log2(m) + log2(s));
		//cout << addresses[i] << " : " << x << "\nIndex : " << setIndex << ", Tag : " << tag << " ~ ";
		//if no block in set
		if (!cache[setIndex])
		{
			//cout << "miss" << endl;
			output << addresses[i] << "          "
				   << "miss\n";
			Block *newBlock = new Block(tag);
			cache[setIndex] = newBlock;
		}
		else
		{
			//if no matching block in set
			if (!findBlock(cache[setIndex], tag, n))
			{
				//cout << "miss" << endl;
				output << addresses[i] << "          "
					   << "miss\n";
				Block *newBlock = new Block(tag);
				newBlock->setNextBlock(cache[setIndex]);
				cache[setIndex] = newBlock;
			}
			//if hit
			else
			{
				//cout << "hit" << endl;
				output << addresses[i] << "          "
					   << "hit\n";
				hit++;
			}
		}

		//just for debugging
		/*for (int j = 0; j < cache.size(); j++)
		{
			if (cache[j])
			{
				cout << j << " => ";
				Block *temp = cache[j];
				do
				{
					cout << temp->getTag() << "->";
					temp = temp->getNextBlock();
				} while (temp);
				cout << "NULL" << endl;
			}
		}
		cout << endl;*/
	}
	output << "# of cache hits"
		   << "     " << hit << endl;
	output << "# of cache misses"
		   << "   " << addresses.size() - hit << endl;
	output.close();

	return 0;
}
